# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['to_do_k8s']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.63.0,<0.64.0',
 'jose>=1.0.0,<2.0.0',
 'passlib>=1.7.4,<2.0.0',
 'pymongo>=3.11.3,<4.0.0',
 'python-dotenv>=0.17.1,<0.18.0',
 'python-jose>=3.2.0,<4.0.0',
 'requests>=2.25.1,<3.0.0',
 'uvicorn>=0.13.4,<0.14.0']

setup_kwargs = {
    'name': 'to-do-k8s',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Sarang Ravindra',
    'author_email': 'cobalt0405@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
